//
//  ViewController.h
//  DemoTest
//
//  Created by 16mm1 on 3/12/17.
//  Copyright © 2017 SInc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    
}

@end

