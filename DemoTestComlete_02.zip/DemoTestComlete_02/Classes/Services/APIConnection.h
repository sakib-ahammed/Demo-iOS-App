//
//  APIConnection.h
//  DemoTest
//
//  Created by 16mm1 on 3/15/17.
//  Copyright © 2017 SInc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>

typedef void(^ServiceErrorBlock)(NSError *error, NSDictionary *errorJSON);

@interface APIConnection : NSObject

// Singleton
+ (instancetype)sharedService;

// defualts
- (AFHTTPRequestOperationManager*)defaultManager;

// General
- (void)performErrorBlock:(ServiceErrorBlock)errorBlock error:(NSError *)error;

- (void)dataFromServerWith:(NSString *)userid successBlock:(void (^)(NSArray* list))successBlock errorBlock:(ServiceErrorBlock)errorBlock;

@end
