//
//  NSDictionary+TD.h
//  Ask4Wifi-Objc
//
//  Created by Jahid on 10/16/15.
//  Copyright © 2015 Jahid. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (TD)

- (id)td_objectForKey:(id)aKey;

@end
