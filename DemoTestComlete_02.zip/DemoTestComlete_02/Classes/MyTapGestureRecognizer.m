//
//  MyTapGestureRecognizer.m
//  ITIW
//
//  Created by ITIW on 9/24/14.
//  Copyright (c) 2014 ITIW. All rights reserved.
//

#import "MyTapGestureRecognizer.h"

@implementation MyTapGestureRecognizer
@synthesize tag,currentTitle;

@end
